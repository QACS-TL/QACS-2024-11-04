﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zoo
{
    public class Spider : Animal
    {
        public override string Eat(string food)
        {
            return $"I'm a spider called {Name} using my {LimbCount} limbs to extract a {food} from my web";
        }
    }
}
