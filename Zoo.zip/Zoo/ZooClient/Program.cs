﻿using Zoo;

Animal animal1 = new Dog("Florence", 4, "Black and White" );

//animal1.name = "Florence";
//animal1.LimbCount = 4;
//animal1.Colour = "Black and White";

//Animal animal2 = new Animal("Boris") {  LimbCount=8, Colour = "Black" };
Animal animal2 = new Spider() { Name="Boris", LimbCount=8, Colour = "Black" };

//animal2.name = "Boris";
//animal2.LimbCount = 8;
//animal2.Colour = "Black";

Animal animal3 = new Spider() { Name= "Maria", LimbCount = 6 };

//Console.WriteLine(animal1.Eat("Grass"));
//Console.WriteLine(animal2.Eat("Flies"));

Dog dog1 = new Dog(limbCount:3, name:"Fido");
//Console.WriteLine(dog1.Eat("Biscuits"));
//Console.WriteLine(dog1.WagTail(10));


List<Animal> zoo = new List<Animal>();
zoo.Add(animal1);
zoo.Add(animal2);
zoo.Add(animal3);
zoo.Add(dog1);

//zoo.Sort();

dog1.Name = "Dolly";

foreach (Animal animal in zoo)
{
    Console.WriteLine(animal.Eat("Candyfloss"));
    if (animal is Dog)
    {
        Console.WriteLine(((Dog)animal).Wave(4));
    }
}

Console.WriteLine($"There are {Animal.AnimalCount} animals");

//IEnumerable<Animal> animals = (from animal in zoo
//                              where animal is Dog
//                              select animal).ToList();

IEnumerable<Animal> animals = zoo.Where(a => a is Dog).Select(a => a).ToList(); 

foreach (Animal animal in animals)
{
    Console.WriteLine(animal);
}


Console.WriteLine();

var animals2 =  from animal in zoo
                where animal.LimbCount > 3
                orderby animal.Name
                select new { animal.Name, animal.Colour };
int sum = zoo.Sum(a => a.LimbCount);

//IEnumerable<Animal>  animals2 = zoo.Where(a => a.LimbCount > 3).OrderBy(a => a.Name).Select(a => { a.Name;, a.Colour }).ToList();
//zoo[1].Name = "Snider";

foreach (var animal in animals2)
{
    Console.WriteLine(animal.Name + ", " + animal.Colour);
}
