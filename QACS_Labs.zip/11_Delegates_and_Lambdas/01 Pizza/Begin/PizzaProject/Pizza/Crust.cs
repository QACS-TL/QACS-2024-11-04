﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaProject
{
    public enum Crust
    {
        Thin_4, Regular_2, Stuffed_3
    }
}
