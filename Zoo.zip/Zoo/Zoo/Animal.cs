﻿namespace Zoo
{
    public class Animal
    {
        public string Name;
        public int LimbCount;
        public string Colour;

        public string Eat(string food)
        {
            return $"I'm an animal called {Name} using some of my {LimbCount} limbs to eat {food}";
        }

        public string Move(int distance, string direction)
        {
            return $"I'm an animal called {Name} using some of my {LimbCount} limbs to move {direction} for {distance} metres";
        }

    }
}
