﻿using Zoo;

Animal animal1 = new Animal();
animal1.Name = "Florence";
animal1.LimbCount = 4;
animal1.Colour = "Black and White";

Animal animal2 = new Animal();
animal2.Name = "Boris";
animal2.LimbCount = 8;
animal2.Colour = "Black";

Console.WriteLine(animal1.Eat("Grass"));
Console.WriteLine(animal2.Eat("Flies"));