﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodsLibrary
{
    //public partial class Car
    //{
    //    public Make Make { get; set; }
    //    public string RegNumber { get; set; }
    //}
}
